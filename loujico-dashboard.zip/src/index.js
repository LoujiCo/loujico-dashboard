
import React from 'react';
import ReactDOM from 'react-dom/client';
import './styles/index.css';

const App = () => {
  return (
    <div className="p-6 text-blue-900 bg-beige-100">
      <h1 className="text-3xl font-bold">Welcome to LoujiCo Dashboard</h1>
      <p>This is the beginning of something powerful.</p>
    </div>
  );
};

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
